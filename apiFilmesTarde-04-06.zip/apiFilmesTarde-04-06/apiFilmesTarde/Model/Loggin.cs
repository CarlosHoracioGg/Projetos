﻿namespace apiFilmesTarde.Model
{
    public class Loggin
    {

        public string usuario { get; set; } = "";
        public string senha { get; set; } = "";
    }
}
