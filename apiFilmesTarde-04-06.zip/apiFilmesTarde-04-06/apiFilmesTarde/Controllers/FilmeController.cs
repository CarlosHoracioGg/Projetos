﻿using apiFilmesTarde.Data;
using apiFilmesTarde.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace apiFilmesTarde.Controllers
{
    [Route("api/[controller]")]/* Cria uma rota chamada /api/filmes (deve erdar o nome antes do Controller que nomeia a classe)*/
    [ApiController]/* Ativa recursos de uma API */
    public class FilmeController : ControllerBase
    {
        private readonly FilmeData filmeData;

        public FilmeController(FilmeData filmeData)
        {
            this.filmeData = filmeData;
        }

        [HttpGet]/* ao pedir essa requisição usa o método abaixo*/
        public IActionResult GetFilmes()
        {
            var filmes = filmeData.filmes();
            return Ok(filmes);
        }

        [HttpGet("{id}")]
        public IActionResult GetFilme(int id)
        {
            var filme = filmeData.filmePorId(id);

            if (filme == null)
            {
                return NotFound($"O filme com o id: {id} não foi encontrado");

            }
            return Ok(filme);
        }
        [Authorize]
        [HttpPost]/* post = cadastro*/

        public IActionResult inserirFilme([FromBody] Filme filme)
        {
            if(filme == null || string.IsNullOrWhiteSpace(filme.titulo))
                /* se filme for vazio ou a linha for vazia ou espaço em branco (filme titulo)*/
            {
                return BadRequest("Dados Inválidos");
                
            }
            filmeData.adicionar(filme);
            /* adiciona o filme na lista*/

            return CreatedAtAction(nameof(GetFilmes), new { titulo = filme.titulo }, filme.titulo);
        }
        [Authorize]
        [HttpDelete("{id}")]
        // função para deletar, ele vai deletar pelo id
        public IActionResult DeleteFilme(int id)
        {
            var sucesso = filmeData.remover(id);
            if (!sucesso)
            {
                return NotFound($"Filme com ID {id} não encontrado,");
            }

            return NoContent();
        }
        [Authorize]
        [HttpPut("{id}")]
        /*função para pegar o filme pelo id*/
        public IActionResult atualizarFilme(int id, [FromBody] Filme filme)
        {
            if(filme == null || string.IsNullOrWhiteSpace(filme.titulo))
            {
                return BadRequest("Dados Inválidos");
            }

            var atualizado = filmeData.atualizarTudo(id, filme);

            if (!atualizado)
            {
                return NotFound($"Filme com {id} não foi encontrado!");
            }

            return NoContent();
        }
        [Authorize]
        [HttpPatch("{id}")] // pacth = atualiza pelo id
        public IActionResult atualizarFilmeParcial(int id, [FromBody]JsonElement campos)
        {
            string? titulo = null;
            string? genero = null;
            int? ano = null;

            if (campos.TryGetProperty("titulo", out var tituloProp))
            {
                titulo = tituloProp.GetString();
            }
            if (campos.TryGetProperty("genero", out var generoProp))
            {
                genero = generoProp.GetString();
            }
            if (campos.TryGetProperty("ano", out var anoProp) && anoProp.TryGetInt32( out var anoVal))
            {
                ano = anoVal;
            }

            var atualizado = this.filmeData.atualizaParcial(id, titulo, genero, ano);
            if (!atualizado)
            {
                return NotFound($"Filme com o id:{id} não encontrado!");
            }
            return NoContent();
        }
    }
}
