﻿namespace apiFilmesTarde.Model
{
    public class Filme
    {
        public int id { get; set; }

        public string titulo { get; set; }

        public string genero { get; set; }

        public int ano { get; set; }

    }
}
