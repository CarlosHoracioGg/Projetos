﻿using apiFilmesTarde.Model;/* Link com a pasta model*/
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Reflection.Metadata.Ecma335;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace apiFilmesTarde.Data

{
    public class FilmeData
    {
        private readonly Database database;

        public FilmeData(Database database)
        {
            this.database = database;
        }

        public IEnumerable<Filme> filmes()
        {
            var filmes = new List<Filme>();
            /*Cria uma lista, armazenando objetos no Filme*/

            using var conn = this.database.GetSqlConnection();

            string sql = "SELECT * FROM Filmes;";
            /* tem os dados da tabela filmes do sql */

            var cmd = new SqlCommand(sql, conn);
            /* armazena o comando dentro do sql e a conexão dentro do conn */

            conn.Open();
            /* inicia a consulta no Sql*/

            using SqlDataReader ler = cmd.ExecuteReader();
            /* Lê os dados retornados pelo ExecuteReader*/
            
            while (ler.Read())/* verifica os dados presentes para poder adicinar algo */
            {
                filmes.Add(new Filme()
                /* Add filmes para lista filmes*/
                {   
                    /* Propriedades*/
                    id = ler.GetInt32(0),
                    titulo = ler.GetString(1),
                    genero = ler.GetString(2),
                    ano = ler.GetInt32(3)
                });
            }
     
            return filmes;
        }

        public Filme? filmePorId(int id)/* Vai buscar um filme pelo id sendo um numero inteiro */
        {
            Filme? filme = null;/* define null como base (não presico colocar um objeto para Filme por contas do: ? */

            using var conn = this.database.GetSqlConnection();

            string sql = "SELECT * FROM Filmes where id = @id;";
            /*cria um comando para selecionar o banco Filmes onde id é igual @id*/

            var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);/* Diz que o Id será igual ao @id */

            conn.Open();

            using SqlDataReader ler = cmd.ExecuteReader();
            
            if (ler.Read())/* Apenas verifica se tem algo ou não */
            {
                filme = new Filme()
                {
                    id = ler.GetInt32(0),
                    titulo = ler.GetString(1),
                    genero = ler.GetString(2),
                    ano = ler.GetInt32(3)
                };
            }
            return filme;
        }

        public void adicionar(Filme filme)
        {
            using var conn = this.database.GetSqlConnection();

            var sql = "INSERT INTO Filmes (Titulo, Genero, Ano) VALUES(@titulo, @genero, @ano);";
            var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@titulo", filme.titulo);
            cmd.Parameters.AddWithValue("@genero", filme.genero);
            cmd.Parameters.AddWithValue("@ano", filme.ano);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public bool remover(int id)
        {
            using var conn = this.database.GetSqlConnection();
            var sql = "DELETE FROM Filmes WHERE Id=@id";
            var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);

            conn.Open();
            int removido = cmd.ExecuteNonQuery();
            return removido > 0;
        }
        
        public bool atualizarTudo(int id, Filme filme)
        {
            var conn = this.database.GetSqlConnection();
            string sql = "UPDATE Filmes SET Titulo = @titulo, Genero = @genero, Ano = @ano WHERE Id = @id";
            /* vai pegar as inf lá no sql*/
            var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@titulo", filme.titulo);
            cmd.Parameters.AddWithValue("@genero", filme.genero);
            cmd.Parameters.AddWithValue("@ano", filme.ano);

            conn.Open();
            return cmd.ExecuteNonQuery() > 0;


        }


        public bool atualizaParcial(int id, string? titulo = null, string? genero = null, int? ano = null)
        {
            var atualizacao = new List<string>();
            var parametros = new List<SqlParameter>();

            if (titulo != null) /* != => diferente de...*/
            {
                atualizacao.Add("titulo = @titulo");
                parametros.Add(new SqlParameter("@titulo", titulo));
            }

            if (genero != null)
            {
                atualizacao.Add("genero = @genero");
                parametros.Add(new SqlParameter("@genero", genero));
            }

            if (ano != null)
            {
                atualizacao.Add("ano = @ano");
                parametros.Add(new SqlParameter("@ano", ano));
            }

            if (!atualizacao.Any())
            {
                return false;
            }

            var sql = $"update filmes set {string.Join(", ", atualizacao)} where id = @id";
            using var conn = this.database.GetSqlConnection();
            var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddRange(parametros.ToArray());

            conn.Open();
            return cmd.ExecuteNonQuery() > 0;

        }


    }
}
