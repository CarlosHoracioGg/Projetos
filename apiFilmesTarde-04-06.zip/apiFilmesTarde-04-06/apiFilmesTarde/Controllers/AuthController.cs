﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace apiFilmesTarde.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {


        private readonly IConfiguration configuration;

        public AuthController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }


        [HttpPost("login")]
        public IActionResult login([FromBody] LoginRequest request)
        {
            if (request.Email != "oclenis@gmail.com" || request.Password != "coringa")
            /* Se email for diferente, ou senha diferrente retorne (não autorizado) 
            Credenciais inválidas*/
            {
                return Unauthorized("Credenciais Inválidas");
            }
            var claims = new[]
                {
              new Claim(ClaimTypes.Email, request.Email),
              new Claim(ClaimTypes.Role, "Admin")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: configuration["Jwt:Issuer"],
                audience: configuration["JwtAudience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(2),
                signingCredentials: creds
            );


            return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
        }
    }
}
