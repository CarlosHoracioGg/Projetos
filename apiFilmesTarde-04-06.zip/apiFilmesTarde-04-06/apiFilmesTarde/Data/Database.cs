﻿using Microsoft.Data.SqlClient;
using System.Runtime.CompilerServices;

namespace apiFilmesTarde.Data
{
    public class Database
    {
        private readonly string connectionString;
        
        public Database(IConfiguration configuration) {
            connectionString = configuration.GetConnectionString("FilmesConnection");
        }

        public SqlConnection GetSqlConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}